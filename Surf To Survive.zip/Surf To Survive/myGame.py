# Surf to Survive Game
#
# @course ICS3UC
# @author Mithran Roy
# @author Japinder Narula
# @date 2019/06/12

# Graphics template taken from programarcadegames.com

# Importing Modules
import pygame
import random
# from os import path

### Main
# Initialize pygame
pygame.init()

# Used to manage how fast the screen updates
clock = pygame.time.Clock()

# Set the width and height of the screen [width, height]
size = (1024, 700)
screen = pygame.display.set_mode(size)

# Give the game a name
pygame.display.set_caption("Surf to Survive")

# Used to manage how fast the screen updates
clock = pygame.time.Clock()


# Load images/graphics
# Image from https://scubasanmateo.com/explore/volcano-clipart-background-tumblr/
volcano_image = pygame.image.load("Volcano Background(small).png")
player_image = pygame.image.load("Surfer.png").convert()
player2_image = pygame.image.load("Surfer1.png").convert()
player3_image = pygame.image.load("Surfer2.png").convert()
player_crouch_image = pygame.image.load("SurferCrouch.png").convert()
bullet_image = pygame.image.load("bullet.png").convert()
tombstone_image = pygame.image.load("Tombstone.png").convert()
water_surface_image = pygame.image.load("Wave.png").convert()
lava_image = pygame.image.load("lava.png").convert()
rock_image = pygame.image.load("Rock.png").convert()
shark_image = pygame.image.load("Shark.png").convert()

# Load background music
background_music = pygame.mixer.Sound("BackgroundMusic.ogg")

# Define some constants
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
BLUE = (0, 0, 255)
GREEN = (0, 255, 0)
ORANGE = (255, 165, 0)
RED = (255, 0, 0)
FPS = 60

# Make backgrounds of images transparent
player_image.set_colorkey(WHITE)
player2_image.set_colorkey(BLACK)
player3_image.set_colorkey(WHITE)
player_crouch_image.set_colorkey(WHITE)
bullet_image.set_colorkey(WHITE)
tombstone_image.set_colorkey(WHITE)
water_surface_image.set_colorkey(WHITE)
lava_image.set_colorkey(WHITE)
rock_image.set_colorkey(BLACK)
shark_image.set_colorkey(WHITE)


### Classes
class Player(pygame.sprite.Sprite):

    # Constructor
    def __init__(self):

        # Call the parent class (Sprite) constructor
        super().__init__()

        # Assign the player to the loaded image
        self.image = player_image

        # Make sure that the obstacles can only hit opaque part of player
        self.mask = pygame.mask.from_surface(self.image)

        # Get the dimensions from image
        self.rect = self.image.get_rect()

        # Assign variables for speeds of player
        self.x_speed = 0
        self.y_speed = 0

        # Variables to see if player is crouching or shooting
        self.crouching = False
        self.shooting = False

        # This variable is to ensure that the first time the space bar is pressed a shot it fired
        self.initialShot = False

    # calc_grav method from http://programarcadegames.com/python_examples/en/sprite_sheets/
    def calc_grav(self):

        # Calculate effect of gravity
        if (self.y_speed == 0):
            self.y_speed = 1
        else:
            self.y_speed += .35

        # See if we are on the ground.
        if (self.rect.y >= 445 and self.y_speed >= 0):
            self.y_speed = 0
            self.rect.y = 445

    # Method to make character jump up
    def jump(self):

        # If it is ok to jump, set our speed upwards
        if (self.rect.y >= 445):
            self.y_speed = -13

    # Method to make character crouch
    def crouch(self):

        # If down arrow key is pressed, change player image to crouching player image
        if (self.crouching == True):
            self.image = player_crouch_image

        # If down arrow key is released, chage player image to normal player image
        else:
            self.image = player_image

        # Make sure that the obstacles can only hit opaque part of player
        self.mask = pygame.mask.from_surface(self.image)

    # Method to shoot water bullets
    def shoot(self):

        # When space bar is pressed shoot every few milliseconds
        if (self.initialShot == True or self.shooting == True and timer % 6 == 0):

            # If player is standing shoot from infront of standing player's face
            if (self.crouching == False):
                bullet = Bullet(player.rect.x + 100, player.rect.y + 5)

            # If player is crouching shoot from infront of crouching player's face
            else:
                bullet = Bullet(player.rect.x + 100, player.rect.y + 51)

            # Add bullets to bullets list, and all sprites list
            bullets_list.add(bullet)
            all_sprites_list.add(bullet)

            # Make sure player shots are spread apart by changing inital shot to false
            player.initialShot = False

    # Method which updates the player position
    def update(self):

        # Calculate gravity so player's landing to ground looks realistic
        self.calc_grav()

        # Shoot (shoot method makes sure bullets only fire when space is pressed)
        self.shoot()

        # Make sure player cannot go offscreen
        if (self.rect.right > 1024):
            self.rect.right = 1024

        elif (self.rect.left < 0):
            self.rect.left = 0

        # Update player position
        self.rect.x += self.x_speed
        self.rect.y += self.y_speed


# Class for the water surface at the bottom of the screen
class Water(pygame.sprite.Sprite):

    # Constructor
    def __init__(self):

        # Call the parent class (Sprite) constructor
        super().__init__()

        # Assign the water to the loaded image
        self.image = water_surface_image

        # Set the x speed to -6 so it is consistently moving left
        self.x_speed = -6

        # Get the dimensions from image
        self.rect = self.image.get_rect()

    # Method which updates the water position
    def update(self):

        # Move water left 6 pixels so it looks like player is moving forward
        self.rect.x += self.x_speed

        # Once the water reaches certain point restart movement loop (so water moves forever)
        if (self.rect.x < -743):
            self.rect.x = -240
            self.rect.y = 573


# Class for the lava obstacle
class Lava(pygame.sprite.Sprite):

    # Constructor
    def __init__(self):

        # Call the parent class (Sprite) constructor
        super().__init__()

        # Create an original image, by assigning the lava to the loaded image, so another one can be used for rotation
        self.image_orig = lava_image

        # Create a copy of the original image to rotate
        self.image = self.image_orig.copy()

        # Set the speeds of the lava
        self.x_speed = -2
        self.y_speed = 2

        # Set a counter so that lava can shake later
        self.counter = 0

        # Get the dimensions from image
        self.rect = self.image.get_rect()

        # Following and rotate method from https://www.youtube.com/watch?v=3Bk-Ny7WLzE&t=213s
        self.rot = 0
        self.rot_speed = random.randrange(1, 8)
        self.last_update = pygame.time.get_ticks()

    # Method to rotate the lava from https://www.youtube.com/watch?v=3Bk-Ny7WLzE&t=213s
    def rotate(self):

        # Set timer
        now = pygame.time.get_ticks()

        # Rotate lava every few seconds
        if (now - self.last_update > 30):
            self.last_update = now
            self.rot = (self.rot + self.rot_speed) % 360
            self.image = pygame.transform.rotate(self.image_orig, self.rot)

    # Method which updates lava position
    def update(self):

        # Rotate the lava
        self.rotate()

        # Move lava left towards player
        self.rect.x += self.x_speed
        self.rect.y += self.y_speed

        # Kill lava if it goes off screen
        if (self.rect.top > 700):
            self.kill()


# Class for slower version of lava which inherits the attributes of lava
class SlowLava(Lava):

    # Constructor
    def __init__(self):

        # Call the parent class (Sprite) constructor
        super().__init__()

        # Set the speeds of the lava
        self.x_speed = 0
        self.y_speed = 0

    # Method to change lava speed so it appears it's shaking
    def changeSpeed(self):

        # Add on to the counter so it can be used for the shaking
        self.counter += 1

        # Speed up lava speed every other second
        if (self.counter % 1000 != 0 and self.y_speed == 0):
            self.y_speed = 2
            self.x_speed = -4

        # Slow down lava speed every other second
        else:
            self.y_speed = 0
            self.x_speed = 1


# Class for the shark obstacle
class Shark(pygame.sprite.Sprite):

    # Constructor
    def __init__(self):

        # Call the parent class (Sprite) constructor
        super().__init__()

        # Assign the shark to the loaded image
        self.image = shark_image

        # Set the x speed to -6 so it is consistently moving left
        self.x_speed = -6

        # Get the dimensions from image
        self.rect = self.image.get_rect()

    # Method which updates shark position
    def update(self):

        # Move shark left 6 pixels so it looks like player is moving forward
        self.rect.x += self.x_speed

        # Kill shark if it goes off screen
        if (self.rect.right < 0):
            self.kill()


# Class for the rocks obstacle
class Rock(Shark):

    # Constructor
    def __init__(self):

        # Call the parent class (Sprite) constructor
        super().__init__()

        # Assign the rock to the loaded image
        self.image = rock_image

        # Set the x speed to -7 so it is consistently moving left
        self.x_speed = -7

        # Set rock lives to 5 so it takes 5 shots to destroy
        self.lives = 5

        # Create a green life bar under the rock
        self.line_length = 40
        self.line_colour = GREEN

        # Get the dimensions from image
        self.rect = self.image.get_rect()

    # Method which updates rock position and life bar
    def update(self):

        # Move rocks left towards player
        self.rect.x += self.x_speed

        # If rock has one life left, life bar turns red
        if (self.lives == 1):
            self.line_colour = RED

        # If rock has two lives left, life bar turns orange
        elif (self.lives == 2):
            self.line_colour = ORANGE

        # Draw and update the life bar every frame
        pygame.draw.line(screen, self.line_colour, [self.rect.x + 25, self.rect.y + 78], [self.rect.x + 25 + self.line_length, self.rect.y + 78], 5)

        # Kill rock sprite if it runs out of lives
        if (self.lives < 1):
            self.kill()

            # Reset rock lives to 5
            self.lives = 5

        # Kill rock if it goes off screen
        if (self.rect.right < 0):
            self.kill()


# Class for bullet
class Bullet(pygame.sprite.Sprite):

    # Constructor, with parameter to take bullet location
    def __init__(self, x, y):

        # Call the parent class (Sprite) constructor
        super().__init__()

        # Assign the bullet to the loaded image
        self.image = bullet_image

        # Make sure that only opaque part of bullets can hit lava
        self.mask = pygame.mask.from_surface(self.image)

        # Get the dimensions from image
        self.rect = self.image.get_rect()

        # Create the bullet location according to parameters
        self.rect.x = x
        self.rect.y = y

        # Set the x speed to 5 so it is consistently moving right
        self.speed_x = 5

    # Method which updates bullet position
    def update(self):
        self.rect.x += self.speed_x

        # Kill bullet if it goes off screen
        if (self.rect.bottom < 0 or self.rect.left > 1024):
            self.kill()


### Subprograms
 # Set fonts
font = pygame.font.SysFont("comicsansms", 72)
font2 = pygame.font.SysFont("comicsansms", 40)
font3 = pygame.font.SysFont("comicsansms", 30)

# Subprogram to draw start screen
def drawStart():

    # Create title
    title = font.render("Surf to Survive", True, (WHITE))

    # Create the story of game
    story = font2.render("Volcanoes have suddenly started to erupt in Hawaii,", True, (WHITE))
    story2 = font2.render("you must SURF TO SURVIVE!", True, (WHITE))

    # Create a line stating creators of game
    creators = font2.render("Game Creators: Mithran Roy and Japinder Narula", True, (WHITE))

    # Create line prompting user to click
    start = font2.render("Click to Continue", True, (WHITE))

    # Create the screen
    pygame.draw.rect(screen, BLUE, [0, 0, 1024, 700])

    # Blit title
    screen.blit(title,(248, 20))

    # Blit player image
    screen.blit(player_image, [411, 130])

    # Blit story and creators
    screen.blit(story, [30, 350])
    screen.blit(story2, [250, 400])
    screen.blit(creators, [30, 490])

    # Blit line prompting user to continue
    screen.blit(start, [360, 630])


# Subprogram to draw instructions screen
def drawInstructions():

    # Create title
    title = font.render("Instructions", True, (WHITE))

    # Create all the instuctions
    instructions = font2.render("Use arrow keys or WASD to control character", True, (WHITE))
    instructionscontd = font2.render("(Up key or W to jump and Down key or S to crouch)", True, (WHITE))
    instructions2 = font2.render("Evade or shoot obstacles, you only have 1 life", True, (WHITE))
    instructions3 = font2.render("Hold space bar to shoot obstacles (increases score)", True, (WHITE))
    instructions3contd = font2.render("(Can't shoot sharks)", True, (WHITE))
    instructions4 = font2.render("Good Luck!", True, (WHITE))

    # Create line prompting user to click
    start = font2.render("Click to Start", True, (WHITE))

    # Create the screen
    pygame.draw.rect(screen, BLUE, [0, 0, 1024, 700])

    # Blit title
    screen.blit(title,(325, 20))

    # Blit the instructions
    screen.blit(instructions, [30, 200])
    screen.blit(instructionscontd, [30, 250])
    screen.blit(instructions2, [30, 350])
    screen.blit(instructions3, [30, 450])
    screen.blit(instructions3contd, [592, 500])
    screen.blit(instructions4, [30, 550])

    # Blit line prompting user to start
    screen.blit(start, [382, 630])


# Subprogram to draw score
def drawScore(score, score2):

    # Create line that displays the score and line that displays the high score
    scoreMsg = font3.render("Score: " + str(score), True, (WHITE))
    bestScoreMsg = font3.render("Highscore: " + str(score2), True, (WHITE))

    # Create the a black box in the top left of the game screen
    pygame.draw.rect(screen, BLACK, [50, 50, 300, 95])

    # Blit the current score and the high score in the black box
    screen.blit(scoreMsg, [50, 50])
    screen.blit(bestScoreMsg, [50, 95])


# Subprogram to draw game over screen
def drawGameOver():

    # Create statement saying the player died
    endMsg = font.render("You Died!", True, (WHITE))

    # Create line prompting user to restart
    restartMsg = font.render("Click to restart", True, (WHITE))

    # Create the screen
    pygame.draw.rect(screen, BLACK, [0, 0, 1024, 700])

    # Blit everything on screen
    # Blit title
    screen.blit(endMsg, (370, 20))

    # Blit tombstone image
    screen.blit(tombstone_image, [300, 135])

    # Blit image prompting user to restart
    screen.blit(restartMsg, [280, 600])


# Subprogram to get high score
def get_high_score():

    # Read the high score from a file
    high_score_file = open("high_score.txt", "r")
    high_score = int(high_score_file.read())
    high_score_file.close()

    return high_score


# Subprogram to save high score
def save_high_score(new_high_score):

    # Write the file to disk
    high_score_file = open("high_score.txt", "w")
    high_score_file.write(str(new_high_score))
    high_score_file.close()



### Main

# Get high score from file
high_score = get_high_score()

# Create all sprite lists
lava_list = pygame.sprite.Group()
slowLava_list = pygame.sprite.Group()
allLava_list = pygame.sprite.Group()
rock1_list = pygame.sprite.Group()
rock2_list = pygame.sprite.Group()
obstacles_list = pygame.sprite.Group()
bullets_list = pygame.sprite.Group()

# This is a list of all sprites
all_sprites_list = pygame.sprite.Group()

# This represents the player
player = Player()
player.rect.x = 50
player.rect.y = 445

# This represents the water
water = Water()
water.rect.x = -30
water.rect.y = 573

# Add the player and the water surface to the list of all sprites
all_sprites_list.add(player)
all_sprites_list.add(water)


# Create variables
# Loop until the user clicks the close button.
done = False

# This variable determines what screen is shown
scene = 0

# This variable is used to determine how often obstacles comes, and how fast bullets are fired
timer = 0

# This variable keeps track of the best score
bestScore = high_score

# This variable keeps track of the current score
score = 0

# These two variables are used for determining how many times the rocks get hit by a bullet
hits = 0
hits1 = 0

# These variables set the amount of lava that will fall and how many sharks come at once
maxLava = 25
sharkAmount = 1

# -------- Main Program Loop -----------
while not done:

    # Play the background music
    background_music.play()

    # --- Main event loop
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            done = True

        # Change the scene with mouse clicks
        elif (event.type == pygame.MOUSEBUTTONDOWN):
            if (scene == 0):
                scene = 1
            elif (scene == 1):
                scene = 2
            elif (scene == 3):
                scene = 1


    # --- Game logic should go here
        if (scene == 2):

            # Hide the mouse cursor
            pygame.mouse.set_visible(0)

            # Check if a key was pressed
            if event.type == pygame.KEYDOWN:

                # Figure out if it was an arrow key
                # If it was a left or right arrow key (or A or D), change player speed
                if (event.key == pygame.K_LEFT or event.key == pygame.K_a):
                    player.x_speed = -5
                elif (event.key == pygame.K_RIGHT or event.key == pygame.K_d):
                    player.x_speed = 5

                # If it was an up arrow key or W and player is on the ground, jump
                elif (event.key == pygame.K_UP or event.key == pygame.K_w and player.rect.y > 440):
                    player.jump()

                # If it was a down arrow or S, make the player crouch
                elif (event.key == pygame.K_DOWN or event.key == pygame.K_s):
                    player.crouching = True
                    player.crouch()

                # If is was the space bar, shoot
                elif (event.key == pygame.K_SPACE):
                    player.shooting = True
                    player.initialShot = True

            # Check if user let up on a key
            elif event.type == pygame.KEYUP:

                # If it was a left or right arrow key, or a or d, reset speed back to zero
                # (Following four lines can be written in two lines, but written in four to make it look neater)
                if (event.key == pygame.K_LEFT or event.key == pygame.K_RIGHT):
                    player.x_speed = 0
                if (event.key == pygame.K_a or event.key == pygame.K_d):
                    player.x_speed = 0

                # If is was a down arrow key or S, stop crouching
                elif (event.key == pygame.K_DOWN or event.key == pygame.K_s):
                    player.crouching = False
                    player.crouch()

                # If it was the space bar, stop shooting
                elif (event.key == pygame.K_SPACE):
                    player.shooting = False


    # --- Screen-clearing code goes here

    # Clear the screen to white
    screen.fill(WHITE)

    # If mouse has not been pressed, draw start screen
    if (scene == 0):
        drawStart()

    # If mouse was pressed in start screen, or game over screen, draw instructions screen
    elif(scene == 1):
        drawInstructions()


    # Draw game once user clicks mouse button in instructions screen
    elif (scene == 2):

        # Draw volcanic background
        screen.blit(volcano_image, [0, 0])

        # Occasionally spawn lava
        if (timer >= 750 and timer % 750 == 0):

            # Choose random number so that there can be different number of fast and slow lavas
            # Make sure 30 - 60 percent is normal lava
            num = random.randrange(maxLava - 17, maxLava - 7)

            # Make sure rest is slow lava
            num2 = maxLava - num

            # This represents lava
            # This for loop creates many normal lava sprites depending on what num is
            for i in range (num):
                lava = Lava()

                # Set a random location for the lava
                # lava.rect.x = random.randrange(700, 950)
                lava.rect.x = random.randrange(700, 1150)
                lava.rect.y = random.randrange(-200, 0)

                # Add the lava to the list of objects
                lava_list.add(lava)
                allLava_list.add(lava)
                obstacles_list.add(lava)
                all_sprites_list.add(lava)


            # This represents slow lava
            # This for loop creates many slow lava sprites depending on what num 2 is
            for i in range (num2):
                slowLava = SlowLava()

                # Set a random location for the slow lava
                slowLava.rect.x = random.randrange(900, 1150)
                slowLava.rect.y = random.randrange(-200, 0)

                # Add the lava to the list of slowLava, allLava, obstacles and all sprites
                slowLava_list.add(slowLava)
                allLava_list.add(slowLava)
                obstacles_list.add(slowLava)
                all_sprites_list.add(slowLava)

            # Increase the amount of lava spawned next time by 10
            maxLava += 10


        # Spawn sharks relatively often
        if (timer == 50 or timer % 400 == 0 and timer != 0):
            # This represents the shark

            # The number of sharks created depends on the sharkAmount variable which increase as the game progresses
            # This for loop creates one shark at first, but that number slowly increases
            for i in range (sharkAmount):

                # Create an instance of a shark
                shark = Shark()

                # Set location for the shark
                shark.rect.x = random.randrange(900, 1100)
                shark.rect.y = 550

                # Add the shark to the list of obstacles and all sprites
                obstacles_list.add(shark)
                all_sprites_list.add(shark)

            # Ocassionally increase the number of sharks
            if (timer >= 2000 and timer % 2000 == 0):
                sharkAmount += 1

        # Spawn rocks more often than lava, but less often than sharks
        if (timer >= 600 and timer % 600 == 0):
            # This represents the rocks
            rocks_list = []

            # This for loop randomly creates 1 or 2 rocks
            for i in range (random.randrange(1, 3)):

                # Create an instance of a rock
                rock = Rock()

                # Set location for the rock
                rock.rect.x = random.randrange(1100, 1200)
                rock.rect.y = random.randrange(380, 485)

                # Add the rocks to rock list, obstacle list, and all sprites list
                rocks_list.append(rock)
                obstacles_list.add(rock)
                all_sprites_list.add(rock)

            # Add the rock to individual rock lists
            rock1_list.add(rocks_list[0])

            # If there are two rocks, add seconds one to rock 2 list
            if (i == 1):
                rock2_list.add(rocks_list[1])

        # Increase timer and score every frame
        timer += 1
        score += 1

        # Check if bullets have hit any lava, if so get rid of lava
        lava_hit_list = pygame.sprite.groupcollide(bullets_list, allLava_list, False, True, pygame.sprite.collide_mask)

        # For every piece of lava hit, increase score by 100
        for hit in lava_hit_list:
            score += 100

        # Check if bullets have hit any rocks in first list, if so get rid of bullet, and after 5 hits get rid of rock
        rock1_hit_list = pygame.sprite.groupcollide(bullets_list, rock1_list, True, False, pygame.sprite.collide_mask)

        # Loop for the number of times a rock is hit
        for hit in rock1_hit_list:
            for rock in rock1_list:

                # Every time a rock is hit decrease 1 life
                rock.lives -= 1

                # Also decrease life bar length
                rock.line_length -= 8

            # Increase variable keeping track of how many times rock is hit
            hits += 1

            # Every time a rock is hit 5 times and destroyed, add 500 to score
            if (hits == 5):
                score += 500

                # Reset hits variable to 0
                hits = 0

        # Check if bullets have hit any rocks in second list, if so get rid of bullet, and after 5 hits get rid of rock
        rock2_hit_list = pygame.sprite.groupcollide(bullets_list, rock2_list, True, False, pygame.sprite.collide_mask)

        # Loop for the number of times a rock is hit
        for hit in rock2_hit_list:
            for rock in rock2_list:

                # Every time a rock is hit decrease 1 life
                rock.lives -= 1

                # Also decrease life bar length
                rock.line_length -= 8

            # Increase variable keeping track of how many times rock is hit
            hits1 += 1

            # Every time a rock is hit 5 times and destroyed, add 500 to score
            if (hits1 == 5):
                score += 500

                # Reset hits1 variable to 0
                hits1 = 0

        # See if the player block has collided with anything.
        player_hit_list = pygame.sprite.spritecollide(player, obstacles_list, True, pygame.sprite.collide_mask)

        # If player was hit, end game
        if (player_hit_list):

            # If this score is greater than high score, make it high score
            if (score > bestScore):
                bestScore = score

            # Change scene to gameover screen
            scene = 3


        # --- Drawing code should go here

            # Draw all the sprites
        all_sprites_list.draw(screen)

        # Call the changeSpeed() method for all lava in the slowLava_list to make it look like it is shaking
        for slowLava in slowLava_list:
            slowLava.changeSpeed()

        # Update all sprites and their locations
        all_sprites_list.update()

        # Draw the score on the top right of game screen
        drawScore(score, bestScore)


    # End game when user hits obstacle
    else:

        # Show the mouse cursor
        pygame.mouse.set_visible(1)

        # Draw the game over screen
        drawGameOver()

        # Reset timer, score, and amount of sharks
        timer = 0
        score = 0
        sharkAmount = 1
        maxLava = 25

        # Reset all the sprite lists
        lava_list = pygame.sprite.Group()
        slowLava_list = pygame.sprite.Group()
        allLava_list = pygame.sprite.Group()
        rock1_list = pygame.sprite.Group()
        rock2_list = pygame.sprite.Group()
        obstacles_list = pygame.sprite.Group()
        bullets_list = pygame.sprite.Group()
        all_sprites_list = pygame.sprite.Group()

        # Reset player position
        player = Player()
        player.rect.x = 50
        player.rect.y = 445

        # Reset water
        water = Water()
        water.rect.x = -30
        water.rect.y = 573

        # Add the player and the water surface to the new list of all sprites
        all_sprites_list.add(player)
        all_sprites_list.add(water)

    # --- Go ahead and update the screen with what we've drawn.
    pygame.display.flip()

    # --- Limit to 60 frames per second
    clock.tick(FPS)


# If the highest score this time is higher than previous highest score, save it
if (bestScore > high_score):
    save_high_score(bestScore)

# Close the window and quit.
pygame.quit()